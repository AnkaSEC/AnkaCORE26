package com.librarymanagementsystem.library_management.service;

import com.librarymanagementsystem.library_management.dto.AuthorRequest;
import com.librarymanagementsystem.library_management.dto.AuthorResponse;
import com.librarymanagementsystem.library_management.entity.Author;
import com.librarymanagementsystem.library_management.exception.BusinessException;
import com.librarymanagementsystem.library_management.exception.ResourceNotFoundException;
import com.librarymanagementsystem.library_management.repository.AuthorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AuthorService {

    private final AuthorRepository authorRepository;

    public AuthorResponse createAuthor(AuthorRequest request) {
        Author author = new Author();
        author.setName(request.getName());
        author.setSurname(request.getSurname());
        author.setBirthDate(request.getBirthDate());
        author.setNationality(request.getNationality());

        Author savedAuthor = authorRepository.save(author);
        return mapToResponse(savedAuthor);
    }

    public List<AuthorResponse> getAllAuthors() {
        return authorRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public AuthorResponse getAuthorById(Long id) {
        Author author = authorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Yazar bulunamadı!"));
        return mapToResponse(author);
    }

    @Transactional
    public void deleteAuthor(Long id) {
        Author author = authorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Yazar bulunamadı!"));

        // İş Kuralı: Yazara ait kitap varsa silme
        if (author.getBooks() != null && !author.getBooks().isEmpty()) {
            throw new BusinessException("Bu yazara ait kayıtlı kitaplar olduğu için silinemez!");
        }

        authorRepository.delete(author);
    }

    private AuthorResponse mapToResponse(Author author) {
        AuthorResponse response = new AuthorResponse();
        response.setId(author.getId());
        response.setFullName(author.getName() + " " + author.getSurname());
        response.setNationality(author.getNationality());
        return response;
    }
}