package com.librarymanagementsystem.library_management.dto;

import lombok.Data;

@Data
public class BookResponse {
    private Long id;
    private String title;
    private String isbn;
    private String authorName;
    private String categoryName;
    private Integer availableCopies;
}