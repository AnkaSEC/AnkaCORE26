package com.librarymanagementsystem.library_management.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDate;

@Data
public class AuthorRequest {

    @NotBlank(message = "Yazar adı boş olamaz")
    @Size(max = 100, message = "Yazar adı en fazla 100 karakter olabilir")
    private String name;

    @NotBlank(message = "Yazar soyadı boş olamaz")
    @Size(max = 100, message = "Yazar soyadı en fazla 100 karakter olabilir")
    private String surname;

    private LocalDate birthDate;

    @Size(max = 50, message = "Uyruk bilgisi en fazla 50 karakter olabilir")
    private String nationality;
}