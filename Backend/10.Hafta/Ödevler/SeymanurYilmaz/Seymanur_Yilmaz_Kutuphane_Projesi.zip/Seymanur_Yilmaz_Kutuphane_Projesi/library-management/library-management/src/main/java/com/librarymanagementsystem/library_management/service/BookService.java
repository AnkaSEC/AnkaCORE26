package com.librarymanagementsystem.library_management.service;

import com.librarymanagementsystem.library_management.dto.BookRequest;
import com.librarymanagementsystem.library_management.dto.BookResponse;
import com.librarymanagementsystem.library_management.entity.Author;
import com.librarymanagementsystem.library_management.entity.Book;
import com.librarymanagementsystem.library_management.entity.Category;
import com.librarymanagementsystem.library_management.exception.ResourceNotFoundException;
import com.librarymanagementsystem.library_management.repository.AuthorRepository;
import com.librarymanagementsystem.library_management.repository.BookRepository;
import com.librarymanagementsystem.library_management.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final CategoryRepository categoryRepository;

    public BookResponse createBook(BookRequest request) {
        Author author = authorRepository.findById(request.getAuthorId())
                .orElseThrow(() -> new ResourceNotFoundException("Yazar bulunamadı!"));

        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Kategori bulunamadı!"));

        Book book = new Book();
        book.setTitle(request.getTitle());
        book.setIsbn(request.getIsbn());
        book.setPublicationYear(request.getPublicationYear());
        book.setTotalCopies(request.getTotalCopies());
        book.setAvailableCopies(request.getTotalCopies());
        book.setAuthor(author);
        book.setCategory(category);

        return mapToResponse(bookRepository.save(book));
    }

    // Sayfalama Desteği
    public Page<BookResponse> getAllBooks(Pageable pageable) {
        return bookRepository.findAll(pageable).map(this::mapToResponse);
    }

    public BookResponse getByIsbn(String isbn) {
        Book book = bookRepository.findByIsbn(isbn)
                .orElseThrow(() -> new ResourceNotFoundException("Bu ISBN numarasına sahip kitap bulunamadı!"));
        return mapToResponse(book);
    }

    private BookResponse mapToResponse(Book book) {
        BookResponse response = new BookResponse();
        response.setId(book.getId());
        response.setTitle(book.getTitle());
        response.setIsbn(book.getIsbn());
        response.setAuthorName(book.getAuthor().getName() + " " + book.getAuthor().getSurname());
        response.setCategoryName(book.getCategory().getName());
        response.setAvailableCopies(book.getAvailableCopies());
        return response;
    }
}