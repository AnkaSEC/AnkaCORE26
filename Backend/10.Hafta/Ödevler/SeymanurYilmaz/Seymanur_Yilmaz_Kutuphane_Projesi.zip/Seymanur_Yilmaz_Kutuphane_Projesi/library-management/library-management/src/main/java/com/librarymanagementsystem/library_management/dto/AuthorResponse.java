package com.librarymanagementsystem.library_management.dto;

import lombok.Data;

@Data
public class AuthorResponse {
    private Long id;
    private String fullName;
    private String nationality;
}