package com.librarymanagementsystem.library_management.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class UserRequest {

    @NotBlank(message = "Email boş olamaz")
    @Email(message = "Geçerli bir email giriniz")
    private String email;

    @NotBlank(message = "İsim boş olamaz")
    @Size(max = 50)
    private String firstName;

    @NotBlank(message = "Soyisim boş olamaz")
    @Size(max = 50)
    private String lastName;

    @Size(max = 20)
    private String phone;
}