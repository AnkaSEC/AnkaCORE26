package com.librarymanagementsystem.library_management.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(nullable = false, length = 50)
    private String firstName;

    @Column(nullable = false, length = 50)
    private String lastName;

    private String phone;

    @Column(nullable = false)
    private LocalDate membershipDate;

    private Boolean isActive = true;

    @OneToMany(mappedBy = "user")
    private List<Borrowing> borrowings;
}