package com.librarymanagementsystem.library_management.repository;

import com.librarymanagementsystem.library_management.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    Optional<Book> findByIsbn(String isbn);
    List<Book> findByTitleContainingIgnoreCase(String title);
    List<Book> findByCategoryId(Long categoryId);
    List<Book> findByAuthorId(Long authorId);
    List<Book> findByAvailableCopiesGreaterThan(int count);
}