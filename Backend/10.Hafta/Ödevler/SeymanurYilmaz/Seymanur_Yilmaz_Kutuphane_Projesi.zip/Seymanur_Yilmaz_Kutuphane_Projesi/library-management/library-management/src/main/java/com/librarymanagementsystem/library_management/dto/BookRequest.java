package com.librarymanagementsystem.library_management.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class BookRequest {

    @NotBlank(message = "Kitap başlığı boş olamaz")
    @Size(max = 200, message = "Kitap başlığı en fazla 200 karakter olabilir")
    private String title;

    @NotBlank(message = "ISBN boş olamaz")
    @Size(min = 13, max = 13, message = "ISBN 13 karakter olmalıdır")
    private String isbn;

    private Integer publicationYear;

    @NotNull(message = "Toplam kopya sayısı boş olamaz")
    @Min(value = 1, message = "Toplam kopya sayısı en az 1 olmalıdır")
    private Integer totalCopies;

    @NotNull(message = "Yazar bilgisi boş olamaz")
    private Long authorId;

    @NotNull(message = "Kategori bilgisi boş olamaz")
    private Long categoryId;
}