package com.librarymanagementsystem.library_management.service;

import com.librarymanagementsystem.library_management.entity.Book;
import com.librarymanagementsystem.library_management.entity.Borrowing;
import com.librarymanagementsystem.library_management.entity.User;
import com.librarymanagementsystem.library_management.exception.BusinessException;
import com.librarymanagementsystem.library_management.exception.ResourceNotFoundException;
import com.librarymanagementsystem.library_management.repository.BookRepository;
import com.librarymanagementsystem.library_management.repository.BorrowingRepository;
import com.librarymanagementsystem.library_management.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class BorrowingService {
    private final BorrowingRepository borrowingRepository;
    private final BookRepository bookRepository;
    private final UserRepository userRepository;

    @Transactional
    public String borrowBook(Long userId, Long bookId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Kullanıcı bulunamadı!"));
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Kitap bulunamadı!"));

        // İş Kuralı: Kullanıcı aktif olmalı
        if (user.getIsActive() == null || !user.getIsActive()) {
            throw new BusinessException("Pasif kullanıcılar kitap ödünç alamaz!");
        }

        // İş Kuralı: Stok kontrolü
        if (book.getAvailableCopies() <= 0) {
            throw new BusinessException("Üzgünüz, bu kitabın mevcut kopyası kalmadı!");
        }

        // İş Kuralı: Bir kullanıcı en fazla 3 kitap alabilir
        long activeBorrowings = borrowingRepository.countByUserIdAndStatus(userId, "BORROWED");
        if (activeBorrowings >= 3) {
            throw new BusinessException("Bir kullanıcı aynı anda en fazla 3 kitap ödünç alabilir!");
        }

        Borrowing borrowing = new Borrowing();
        borrowing.setUser(user);
        borrowing.setBook(book);
        borrowing.setBorrowDate(LocalDate.now());
        borrowing.setDueDate(LocalDate.now().plusDays(30)); // Dokümanda 30 gün istenmiş
        borrowing.setStatus("BORROWED");

        book.setAvailableCopies(book.getAvailableCopies() - 1);

        borrowingRepository.save(borrowing);
        bookRepository.save(book);

        log.info("Kitap ödünç verildi: Kitap: {}, Kullanıcı: {}", book.getTitle(), user.getEmail());
        return book.getTitle() + " başarıyla ödünç verildi. Son iade tarihi: " + borrowing.getDueDate();
    }

    @Transactional
    public String returnBook(Long borrowingId) {
        Borrowing borrowing = borrowingRepository.findById(borrowingId)
                .orElseThrow(() -> new ResourceNotFoundException("Ödünç işlemi bulunamadı!"));

        if ("RETURNED".equals(borrowing.getStatus())) {
            throw new BusinessException("Bu kitap zaten iade edilmiş.");
        }

        borrowing.setReturnDate(LocalDate.now());
        borrowing.setStatus("RETURNED");

        // İş Kuralı: İade tarihi kontrolü ve ceza (Günlük 5 TL)
        long lateDays = ChronoUnit.DAYS.between(borrowing.getDueDate(), LocalDate.now());
        double fine = lateDays > 0 ? lateDays * 5.0 : 0;

        Book book = borrowing.getBook();
        book.setAvailableCopies(book.getAvailableCopies() + 1);

        bookRepository.save(book);
        borrowingRepository.save(borrowing);

        String message = book.getTitle() + " iade edildi.";
        return fine > 0 ? message + " Gecikme cezası: " + fine + " TL" : message;
    }

    public List<Borrowing> getAllBorrowings() {
        return borrowingRepository.findAll();
    }
}