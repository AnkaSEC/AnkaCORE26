package com.librarymanagementsystem.library_management.dto;
import lombok.Data;
import java.time.LocalDate;

@Data
public class UserResponse {
    private Long id;
    private String email;
    private String firstName;
    private String lastName;
    private LocalDate membershipDate;
    private boolean active;
}