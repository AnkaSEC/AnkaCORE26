package com.librarymanagementsystem.library_management.service;

import com.librarymanagementsystem.library_management.entity.Category;
import com.librarymanagementsystem.library_management.exception.BusinessException;
import com.librarymanagementsystem.library_management.exception.ResourceNotFoundException;
import com.librarymanagementsystem.library_management.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService {

    private final CategoryRepository categoryRepository;

    public Category createCategory(Category category) {
        if (categoryRepository.existsByName(category.getName())) {
            throw new BusinessException("Bu isimde bir kategori zaten mevcut!");
        }
        return categoryRepository.save(category);
    }

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    public void deleteCategory(Long id) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Kategori bulunamadı!"));

        if (category.getBooks() != null && !category.getBooks().isEmpty()) {
            throw new BusinessException("Bu kategoriye ait kitaplar olduğu için silinemez!");
        }

        categoryRepository.delete(category);
    }
}