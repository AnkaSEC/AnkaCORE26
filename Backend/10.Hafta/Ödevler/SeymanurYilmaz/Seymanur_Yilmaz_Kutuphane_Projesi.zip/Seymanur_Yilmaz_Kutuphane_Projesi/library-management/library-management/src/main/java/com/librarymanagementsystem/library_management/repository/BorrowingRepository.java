package com.librarymanagementsystem.library_management.repository;

import com.librarymanagementsystem.library_management.entity.Borrowing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BorrowingRepository extends JpaRepository<Borrowing, Long> {

    long countByUserIdAndStatus(Long userId, String status);

    List<Borrowing> findByStatus(String status);
}